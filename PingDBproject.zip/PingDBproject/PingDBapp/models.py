from django.db import models
from django.utils import timezone

class PingPongPaddle(models.Model):
    serial_number = models.CharField(max_length=50)
    weight = models.FloatField()
    price = models.FloatField()
    image_url = models.CharField(max_length=255)
    qr_url = models.CharField(max_length=255)
    def __str__(self):
        return self.serial_number


class Customer_Sales(models.Model):
    # paddle = models.OneToOneField(PingPongPaddle, on_delete=models.CASCADE)
    paddle = models.ForeignKey(PingPongPaddle, on_delete=models.CASCADE)
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    email = models.EmailField()
    date_of_sale = models.DateTimeField(auto_now_add=True)
    paid = models.BooleanField(default=False)
    shipped = models.BooleanField(default=False)
