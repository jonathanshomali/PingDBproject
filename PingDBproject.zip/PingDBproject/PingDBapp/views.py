from django.shortcuts import render, redirect, get_object_or_404
from django.views.generic.edit import UpdateView, DeleteView
from django.urls import reverse_lazy 
from .models import PingPongPaddle, Customer_Sales
from .forms import PingPongPaddleForm, Customer_SalesForm
import os
from django.conf import settings
import pandas as pd
from django.http import HttpResponse
import io
from django.utils import timezone

def paddle_view(request):
    form = PingPongPaddleForm()
    paddles = PingPongPaddle.objects.all()
    paddles_with_sales = []
    image_dir = os.path.join(settings.STATIC_ROOT, 'paddle_images')
    images = os.listdir(image_dir)
    qr_dir = os.path.join(settings.STATIC_ROOT, 'qr_images')
    qr = os.listdir(qr_dir)

    if request.method == "POST":
        form = PingPongPaddleForm(request.POST)
        if form.is_valid():
            instance = form.save(commit=False)  # Define instance first
            image_url = request.POST.get('image_url')
            if image_url is not None:
                instance.image_url = 'paddle_images/' + image_url
            else:
                pass
            qr_url = request.POST.get('qr_url')
            if qr_url is not None:
                instance.qr_url = 'qr_images/' + qr_url
            else:
                pass
            instance.save()
    else:
        form = PingPongPaddleForm()
    for paddle in paddles:
        paddle_sales = Customer_Sales.objects.filter(paddle=paddle)
        print(paddle_sales)
        paddles_with_sales.append((paddle, paddle_sales))
    context = {'form': form, 'paddles_with_sales': paddles_with_sales, 'images': images, 'qr': qr}
    return render(request, 'PingDBapp/paddle_form.html', context)

def customer_sales(request, paddle_id):
    paddle = get_object_or_404(PingPongPaddle, id=paddle_id)
    if request.method == 'POST':
        form = Customer_SalesForm(request.POST)
        if form.is_valid():
            sale = form.save()
            sale.paddle = paddle
            sale.save()
            return redirect('paddle_view')
    else:
        form = Customer_SalesForm()
    return render(request, 'PingDBapp/customer_sales_form.html', {'form': form})

def modify_customer_sales(request, paddle_id):
    paddle = get_object_or_404(PingPongPaddle, pk=paddle_id)
    if request.method == 'POST':
        form = Customer_SalesForm(request.POST, instance=paddle.customer_sales)
        if form.is_valid():
            form.save()
            return redirect('paddle_view', paddle_id=paddle.id)
    else:
        form = Customer_SalesForm(instance=paddle.customer_sales)
    return render(request, 'customer_sales_form.html', {'form': form})

def create_or_update_customer_sales(request, sales_id=None):
    if sales_id:
        sales = get_object_or_404(Customer_Sales, id=sales_id)
        action = "Modify"
    else:
        sales = None
        action = "Checkout"
    if request.method == 'POST':
        form = Customer_SalesForm(request.POST, instance=sales)
        if form.is_valid():
            form.save()
            return redirect('home') # Redirect to home page after successful creation/update
    else:
        form = Customer_SalesForm(instance=sales)
    return render(request, 'customer_sales_form.html', {'form': form, 'action': action})


def checkout(request, paddle_id):
    paddle = get_object_or_404(PingPongPaddle, id=paddle_id)
    if request.method == 'POST':
        customer_sale_form = Customer_SalesForm(request.POST)
        if customer_sale_form.is_valid():
            customer_sales = customer_sale_form.save()
            customer_sales.paddle = paddle
            customer_sales.save()
            return redirect('paddle_view')
    else:
        customer_sales_form = Customer_SalesForm()
    return render(request, 'PingDBapp/checkout.html', {'customer_sales_form': customer_sales_form})

def update_customer_sales(request, sales_id):
    sales = get_object_or_404(Customer_Sales, id=sales_id)
    if request.method == 'POST':
        form = Customer_SalesForm(request.POST, instance=sales)
        if form.is_valid():
            form.save()
            return redirect('paddle_view') # Replace with your view name to redirect after successful update
    else:
        form = Customer_SalesForm(instance=sales)
    return render(request, 'update_customer_sales.html', {'form': form})    

def my_view(request):
    if request.method == 'POST':
        form = PingPongPaddleForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('paddle_view')
    else:
        form = PingPongPaddleForm()
    return render(request, 'PingDBapp/paddle_form.html', {'form': form})

def export_to_excel(request):
    # Fetch all paddles
    paddles = PingPongPaddle.objects.all()
    # Initialize an empty list to hold the data
    data = []
    for paddle in paddles:
        # Fetch the related sale if it exists
        sale = paddle.customer_sales_set.first()
        if sale is not None:
            # Append the data for this sale
            # Convert the datetime to a timezone-naive datetime in UTC
            date_of_sale_naive = timezone.make_naive(sale.date_of_sale, timezone=timezone.utc)
            data.append([
                paddle.image_url,
                paddle.qr_url,
                paddle.serial_number,
                paddle.weight,
                paddle.price,
                sale.first_name,
                sale.last_name,
                sale.email,
                date_of_sale_naive,
                sale.paid,
                sale.shipped,
            ])
        else:
            # Append paddle data with empty sales data
            data.append([
                paddle.image_url,
                paddle.qr_url,
                paddle.serial_number,
                paddle.weight,
                paddle.price,
                '',
                '',
                '',
                '',
                '',
                '',
            ])
    # Convert the data to a pandas DataFrame
    df = pd.DataFrame(data, columns=['Image', 'QR_Image','Serial Number', 'Weight', 'Price', 'First Name', 'Last Name', 'Email', 'Date of Sale', 'Paid', 'Shipped'])
    # Create a HttpResponse object with the Excel file
    response = HttpResponse(content_type='application/vnd.ms-excel')
    response['Content-Disposition'] = 'attachment; filename=PingPongSales.xlsx'
    # Write the DataFrame to the response
    df.to_excel(response, index=False)
    return response


class PaddleUpdateView(UpdateView):
    model = PingPongPaddle
    form_class = PingPongPaddleForm
    template_name = 'PingDBapp/paddle_update.html'  # name of your update template
    success_url = reverse_lazy('paddle_view')  # redirects to the list view after a successful update

class PaddleDeleteView(DeleteView):
    model = PingPongPaddle
    template_name = 'PingDBapp/paddle_delete.html'  # name of your delete template
    success_url = reverse_lazy('paddle_view')  # redirects to the list view after a successful delete

