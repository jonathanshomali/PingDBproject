from django.urls import path
from . import views
from .views import PaddleUpdateView, PaddleDeleteView, export_to_excel
urlpatterns = [
    path('', views.paddle_view, name='paddle_view'),
    path('<int:pk>/update/', PaddleUpdateView.as_view(), name='paddle_update'),
    path('<int:pk>/delete/', PaddleDeleteView.as_view(), name='paddle_delete'),
    path('customer_sales_form/<int:paddle_id>', views.customer_sales, name="customer_sales_form"), 
    path('checkout/<int:paddle_id>/', views.checkout, name='checkout'),
    path('update-customer-sales/<int:sales_id>/', views.update_customer_sales, name='update_customer_sales'),
    path('export-to-excel/', export_to_excel, name='export_to_excel'),
    path('sales-form/<int:sales_id>/', views.create_or_update_customer_sales, name='sales_form_update'),
    path('sales-form/', views.create_or_update_customer_sales, name='sales_form_create'),
    path('modify_sales/<int:paddle_id>/', views.modify_customer_sales, name='modify_sales'),
]
