from django import forms
from .models import PingPongPaddle, Customer_Sales
import os
from django.conf import settings

class PingPongPaddleForm(forms.ModelForm):
    IMAGE_DIR = 'paddle_images'
    image_choices = [
        (f, f) for f in os.listdir(os.path.join(settings.STATICFILES_DIRS[0], IMAGE_DIR))
    ]
    image_url = forms.ChoiceField(choices=image_choices)

    QR_DIR = 'qr_images'
    qr_choices = [
        (f,f) for f in os.listdir(os.path.join(settings.STATICFILES_DIRS[0], QR_DIR))
    ]
    qr_url = forms.ChoiceField(choices=qr_choices)
    class Meta:
        model = PingPongPaddle
        fields = [
                  'image_url',
                  'qr_url',
                   'serial_number',
                    'weight',
                    'price']

class Customer_SalesForm(forms.ModelForm):
    new_sale = forms.BooleanField(initial=True, widget=forms.HiddenInput)    
    class Meta:
        model = Customer_Sales
        fields = ['paddle',
                  'first_name',
                  'last_name',
                  'email',
                  'paid',
                  'shipped']

