import os
os.system('python manage.py runserver')
